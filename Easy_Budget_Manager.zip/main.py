# Monster AI Generated
# Owner: Abhinav
AD_UNIT_ID = 'ca-app-pub-3940256099942544/8691691433'
print('Easy_Budget_Manager Running...')