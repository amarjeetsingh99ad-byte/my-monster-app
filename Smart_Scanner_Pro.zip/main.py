# Monster AI Generated
# Owner: Abhinav
AD_UNIT_ID = 'ca-app-pub-3940256099942544/1033173712'
print('Smart_Scanner_Pro Running...')